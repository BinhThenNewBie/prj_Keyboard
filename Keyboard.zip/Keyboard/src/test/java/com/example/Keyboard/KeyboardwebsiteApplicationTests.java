package com.example.Keyboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeyboardwebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
