package com.example.Keyboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeyboardwebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeyboardwebsiteApplication.class, args);
	}

}
